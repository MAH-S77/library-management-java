package part01;

public enum BookType {
    FICTION, NON_FICTION, REFERENCE
}