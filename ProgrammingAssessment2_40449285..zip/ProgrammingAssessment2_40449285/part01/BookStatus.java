package part01;

public enum BookStatus {
    AVAILABLE, ON_LOAN, WITHDRAWN
}